import React from 'react';

export function StickyNote({ children, width = 160, style }) {
  return (
    <div style={{ width, background: 'var(--note)', border: '1px solid var(--note-edge)', borderRadius: 'var(--radius-md)',
      padding: '10px 11px', fontSize: 12, lineHeight: 1.5, color: 'var(--text-body)', fontFamily: 'var(--font-ui)',
      boxShadow: '0 2px 6px rgba(22,32,29,0.08)', ...style }}>{children}</div>
  );
}
