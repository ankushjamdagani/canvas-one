/** Human aside on the canvas — the only warm-paper surface in the system. */
export interface StickyNoteProps { children?: React.ReactNode; width?: number; style?: React.CSSProperties; }
export function StickyNote(props: StickyNoteProps): JSX.Element;
