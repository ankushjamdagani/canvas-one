import React from 'react';

export function Boundary({ label, children, style }) {
  return (
    <div style={{ border: '1px dashed var(--green-edge)', background: 'rgba(234,239,236,0.5)', borderRadius: 'var(--radius-panel)',
      padding: '8px 10px', fontFamily: 'var(--font-ui)', ...style }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', color: 'var(--green)' }}>{label}</span>
      {children}
    </div>
  );
}
