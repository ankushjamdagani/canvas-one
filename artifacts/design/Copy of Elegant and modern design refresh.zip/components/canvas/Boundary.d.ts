/** Dashed subsystem grouping drawn behind nodes. */
export interface BoundaryProps { label?: string; children?: React.ReactNode; style?: React.CSSProperties; }
export function Boundary(props: BoundaryProps): JSX.Element;
