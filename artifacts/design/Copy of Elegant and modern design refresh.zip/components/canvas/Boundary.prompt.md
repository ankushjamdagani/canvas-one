Subsystem boundary.

```jsx
<Boundary label="FULFILMENT SUBSYSTEM" style={{width:360,height:200}} />
```
