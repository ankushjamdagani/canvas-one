Canvas note.

```jsx
<StickyNote>Confirm the DLQ drain job owner before the review.</StickyNote>
```
