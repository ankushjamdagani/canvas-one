The floating dock. Groups render with hairline dividers between them.

```jsx
<Dock groups={[
  [{glyph:'↺'},{glyph:'↻',state:'disabled'}],
  [{glyph:'↖',label:'Select'},{glyph:'✥'}],
  [{glyph:'−'},{readout:'100%'},{glyph:'＋'},{glyph:'⤢'}]
]} />
```
