import React from 'react';
import { IconButton } from '../core/IconButton.jsx';

export function Dock({ groups = [], style }) {
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '7px 9px', background: 'var(--canvas-white)',
      border: '1px solid var(--border)', borderRadius: 'var(--radius-dock)', boxShadow: 'var(--shadow-floating)',
      fontFamily: 'var(--font-ui)', ...style }}>
      {groups.map((g, gi) => (
        <React.Fragment key={gi}>
          {gi > 0 && <span style={{ width: 1, height: 22, background: 'var(--hairline-soft)' }} />}
          <div style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
            {g.map((it, i) => {
              if (it.readout) return <span key={i} style={{ minWidth: 44, textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: 11.5, fontWeight: 500, color: 'var(--text-body)' }}>{it.readout}</span>;
              if (it.label) {
                const sel = it.state === 'selected';
                return (
                  <span key={i} onClick={it.onClick} style={{ display: 'flex', alignItems: 'center', gap: 7, height: 32, padding: '0 11px',
                    borderRadius: 'var(--radius-md)', cursor: 'pointer',
                    background: sel ? 'var(--ink)' : 'var(--green-tint)', color: sel ? 'var(--text-on-ink)' : 'var(--green)',
                    border: sel ? '1px solid var(--ink)' : '1px solid var(--green-edge)' }}>
                    <span style={{ fontSize: 13 }}>{it.glyph}</span><span style={{ fontSize: 13, fontWeight: 600 }}>{it.label}</span>
                  </span>
                );
              }
              return <IconButton key={i} glyph={it.glyph} state={it.state || 'rest'} onClick={it.onClick} />;
            })}
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}
