import React from 'react';

const STRIPE = { service: 'var(--green)', queue: 'var(--purple)', store: 'var(--clay)', pattern: 'var(--green)' };

export function Node({ title, meta, kind = 'service', state = 'default', ports, style }) {
  const looks = {
    default:  { border: '1px solid var(--border)', boxShadow: 'none', opacity: 1 },
    hover:    { border: '1px solid var(--border-strong)', boxShadow: 'var(--shadow-lifted)', opacity: 1 },
    selected: { border: '1px solid var(--green)', boxShadow: '0 0 0 3px rgba(11,92,84,0.14)', opacity: 1 },
    drop:     { border: '1px dashed var(--green)', boxShadow: '0 18px 34px -16px rgba(22,32,29,0.3)', opacity: 1 },
    dimmed:   { border: '1px solid var(--border)', boxShadow: 'none', opacity: 0.5 },
    alerting: { border: '1px solid var(--clay)', boxShadow: 'var(--ring-danger-soft)', opacity: 1 }
  }[state];
  const showPorts = ports ?? state === 'selected';
  return (
    <div style={{ width: 176, boxSizing: 'border-box', background: 'var(--canvas-white)', borderRadius: 'var(--radius-node)',
      overflow: showPorts ? 'visible' : 'hidden', position: 'relative', fontFamily: 'var(--font-ui)', ...looks, ...style }}>
      <div style={{ height: 3, background: STRIPE[kind] || STRIPE.service, borderTopLeftRadius: 8, borderTopRightRadius: 8 }} />
      <div style={{ padding: '10px 12px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: state === 'drop' ? 'var(--green)' : 'var(--text-primary)' }}>{title}</div>
        {meta && <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, marginTop: 3,
          color: state === 'alerting' ? 'var(--clay)' : state === 'drop' ? '#6B8F87' : 'var(--text-meta)' }}>{meta}</div>}
      </div>
      {showPorts && ['left', 'right'].map(side => (
        <span key={side} style={{ position: 'absolute', [side]: -4, top: '50%', width: 8, height: 8, marginTop: -4, borderRadius: '50%', background: 'var(--green)' }} />
      ))}
    </div>
  );
}
