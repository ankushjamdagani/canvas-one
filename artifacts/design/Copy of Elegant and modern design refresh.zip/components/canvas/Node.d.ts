/**
 * The 176px canvas node. The 3px top stripe is the node kind; the border carries state.
 * @startingPoint section="Canvas" subtitle="Node card in every canvas state" viewport="700x180"
 */
export interface NodeProps {
  title?: string;
  /** mono sub-line: type and one live number */
  meta?: string;
  kind?: 'service' | 'queue' | 'store' | 'pattern';
  state?: 'default' | 'hover' | 'selected' | 'drop' | 'dimmed' | 'alerting';
  /** force the connection ports on; defaults to on when selected */
  ports?: boolean;
  style?: React.CSSProperties;
}
export function Node(props: NodeProps): JSX.Element;
