/**
 * The studio's single floating control bar. Nothing else in the system takes the floating shadow.
 * @startingPoint section="Canvas" subtitle="Floating tool dock with grouped controls" viewport="700x120"
 */
export interface DockItem {
  glyph?: string;
  /** present for a wide labelled tool chip */
  label?: string;
  /** mono readout cell, e.g. "100%" */
  readout?: string;
  state?: 'rest' | 'hover' | 'active' | 'selected' | 'disabled';
  onClick?: () => void;
}
export interface DockProps {
  /** each inner array is a group; groups are separated by a hairline divider */
  groups?: DockItem[][];
  style?: React.CSSProperties;
}
export function Dock(props: DockProps): JSX.Element;
