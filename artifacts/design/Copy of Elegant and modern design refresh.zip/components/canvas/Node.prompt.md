Canvas node.

```jsx
<Node title="Checkout API" meta="SERVICE · p99 180ms" state="selected" />
```

Kinds set the stripe colour (service/pattern green, queue purple, store clay). States: default, hover, selected (ports appear), drop (dashed preview), dimmed (out of focus), alerting.
