import React from 'react';

export function Tabs({ tabs = [], value, onChange, style }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1px solid var(--hairline)', fontFamily: 'var(--font-ui)', ...style }}>
      {tabs.map(t => {
        const on = t.id === value;
        return (
          <div key={t.id} onClick={() => !t.disabled && onChange && onChange(t.id)}
            style={{ padding: '9px 13px', display: 'flex', alignItems: 'center', gap: 7,
              borderBottom: `2px solid ${on ? 'var(--green)' : 'transparent'}`,
              cursor: t.disabled ? 'not-allowed' : 'pointer' }}>
            <span style={{ fontSize: 12.5, fontWeight: on ? 600 : 400,
              color: t.disabled ? 'var(--text-disabled)' : on ? 'var(--green)' : 'var(--text-secondary)' }}>{t.label}</span>
            {t.count != null && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, borderRadius: 20, padding: '1px 7px',
              color: on ? 'var(--text-on-green)' : 'var(--text-body)', background: on ? 'var(--green)' : 'var(--sunken)' }}>{t.count}</span>}
            {t.menu && <span style={{ fontSize: 12, color: 'var(--text-meta)' }}>⋯</span>}
          </div>
        );
      })}
    </div>
  );
}
