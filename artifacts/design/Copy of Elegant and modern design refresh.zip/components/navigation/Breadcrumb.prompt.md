Top-bar breadcrumb. The branch segment is always purple with the ⑂ glyph.

```jsx
<Breadcrumb path="Checkout path" branch="async-fulfilment" />
```
