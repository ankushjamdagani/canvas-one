import React from 'react';

export function Segmented({ options = [], value, onChange, style }) {
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 2, background: 'var(--sunken)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-control)', padding: 2, fontFamily: 'var(--font-ui)', ...style }}>
      {options.map(o => {
        const id = typeof o === 'string' ? o : o.id;
        const label = typeof o === 'string' ? o : o.label;
        const on = id === value;
        return <span key={id} onClick={() => onChange && onChange(id)}
          style={{ padding: '4px 10px', borderRadius: 5, fontSize: 11.5, cursor: 'pointer',
            background: on ? 'var(--canvas-white)' : 'transparent', color: on ? 'var(--green)' : 'var(--text-meta)',
            boxShadow: on ? '0 1px 2px rgba(22,32,29,0.10)' : 'none' }}>{label}</span>;
      })}
    </div>
  );
}
