/** Document name plus the branch you are on. */
export interface BreadcrumbProps { path?: string; branch?: string; style?: React.CSSProperties; }
export function Breadcrumb(props: BreadcrumbProps): JSX.Element;
