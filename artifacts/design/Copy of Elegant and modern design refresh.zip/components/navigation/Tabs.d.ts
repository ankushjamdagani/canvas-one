/**
 * Underlined tab strip. In docked panels the tab strip IS the panel header and the drag handle.
 * @startingPoint section="Navigation" subtitle="Tab strip with counts and per-tab menus" viewport="700x120"
 */
export interface TabItem { id: string; label: string; count?: number; disabled?: boolean; menu?: boolean; }
export interface TabsProps { tabs?: TabItem[]; value?: string; onChange?: (id: string) => void; style?: React.CSSProperties; }
export function Tabs(props: TabsProps): JSX.Element;
