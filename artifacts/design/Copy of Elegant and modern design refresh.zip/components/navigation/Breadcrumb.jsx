import React from 'react';

export function Breadcrumb({ path = 'Checkout path', branch, style }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-ui)', ...style }}>
      <span style={{ fontSize: 13, fontWeight: 500 }}>{path}</span>
      {branch && <>
        <span style={{ color: 'var(--text-disabled)', fontSize: 11 }}>/</span>
        <span style={{ fontSize: 11, color: 'var(--purple)' }}>⑂</span>
        <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--purple)' }}>{branch}</span>
        <span style={{ fontSize: 10, color: 'var(--text-meta)' }}>▾</span>
      </>}
    </div>
  );
}
