Popover menu. One destructive row at the bottom, below a divider.

```jsx
<Menu heading="PART" items={[
  {glyph:'✎',label:'Rename',shortcut:'F2'},
  {glyph:'⊞',label:'Save to library',selected:true},
  {divider:true},
  {glyph:'⌫',label:'Delete part',danger:true,shortcut:'⌦'}
]} />
```
