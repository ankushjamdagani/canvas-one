/** Icon + mono label rail entry; the active one gets a green spine on the outer edge. */
export interface RailItemProps {
  glyph: string; label: string;
  state?: 'rest' | 'hover' | 'active' | 'disabled';
  onClick?: () => void; style?: React.CSSProperties;
}
export function RailItem(props: RailItemProps): JSX.Element;
