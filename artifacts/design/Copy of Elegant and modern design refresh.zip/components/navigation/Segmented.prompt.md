View switch — list vs grid, and similar binary views.

```jsx
<Segmented value="list" options={[{id:'list',label:'☰ List'},{id:'grid',label:'⊞ Grid'}]} />
```
