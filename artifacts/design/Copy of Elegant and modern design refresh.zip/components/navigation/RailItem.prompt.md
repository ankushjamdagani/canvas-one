Rail entry — used in the left tool rail and in collapsed panel rails.

```jsx
<RailItem glyph="＋" label="ADD" state="active" />
```
