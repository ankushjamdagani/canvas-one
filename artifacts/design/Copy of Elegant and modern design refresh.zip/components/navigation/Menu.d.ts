/**
 * Popover menu — context menus, the tab ⋯ menu, the dock's overflow.
 * @startingPoint section="Navigation" subtitle="Popover menu with glyphs, shortcuts, danger row" viewport="700x300"
 */
export interface MenuItem {
  label?: string; glyph?: string; shortcut?: string;
  selected?: boolean; highlighted?: boolean; disabled?: boolean; danger?: boolean; divider?: boolean;
  onClick?: () => void;
}
export interface MenuProps { heading?: string; items?: MenuItem[]; width?: number; style?: React.CSSProperties; }
export function Menu(props: MenuProps): JSX.Element;
