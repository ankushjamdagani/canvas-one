Tab strip; the active tab carries a green 2px underline and an accent count.

```jsx
<Tabs value="standard" tabs={[{id:'standard',label:'Standard',count:48},{id:'ours',label:'Ours',count:3}]} />
```

Set `menu` on a tab to show its ⋯ affordance — that menu holds dock right / dock left / float / collapse / reset width / close.
