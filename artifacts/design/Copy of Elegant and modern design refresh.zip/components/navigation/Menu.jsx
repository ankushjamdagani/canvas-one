import React from 'react';

export function Menu({ heading, items = [], width = 300, style }) {
  return (
    <div style={{ width, background: 'var(--canvas-white)', border: '1px solid var(--border)', borderRadius: 'var(--radius-popover)',
      boxShadow: 'var(--shadow-popover)', overflow: 'hidden', fontFamily: 'var(--font-ui)', ...style }}>
      <div style={{ padding: '8px 8px 6px', display: 'flex', flexDirection: 'column', gap: 1 }}>
        {heading && <div style={{ padding: '5px 9px 6px', fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.12em', color: 'var(--text-meta)' }}>{heading}</div>}
        {items.map((it, i) => it.divider
          ? <div key={i} style={{ height: 1, background: 'var(--hairline-soft)', margin: '5px 4px' }} />
          : (() => {
              const tone = it.disabled ? 'var(--text-disabled)' : it.danger ? 'var(--clay)' : it.selected ? 'var(--green)' : 'var(--text-primary)';
              return (
                <div key={i} onClick={() => !it.disabled && it.onClick && it.onClick()}
                  style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 9px', borderRadius: 'var(--radius-control)',
                    background: it.selected ? 'var(--green-tint)' : it.highlighted ? 'var(--sunken)' : 'transparent',
                    cursor: it.disabled ? 'not-allowed' : 'pointer' }}>
                  {it.glyph && <span style={{ fontSize: 12, color: tone }}>{it.glyph}</span>}
                  <span style={{ fontSize: 13, fontWeight: it.selected ? 600 : it.highlighted ? 500 : 400, color: tone }}>{it.label}</span>
                  {it.shortcut && <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 10, color: it.danger ? '#D3A891' : 'var(--text-meta)' }}>{it.shortcut}</span>}
                  {it.selected && !it.shortcut && <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--green)' }}>✓</span>}
                </div>
              );
            })()
        )}
      </div>
    </div>
  );
}
