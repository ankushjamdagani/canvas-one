/** Two- or three-way view switch. */
export interface SegmentedProps {
  options?: (string | { id: string; label: string })[];
  value?: string; onChange?: (id: string) => void; style?: React.CSSProperties;
}
export function Segmented(props: SegmentedProps): JSX.Element;
