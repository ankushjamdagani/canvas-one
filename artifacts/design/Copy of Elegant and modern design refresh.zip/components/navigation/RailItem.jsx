import React from 'react';

export function RailItem({ glyph, label, state = 'rest', onClick, style }) {
  const looks = {
    active:   { background: 'var(--green-tint)', glyph: 'var(--green)', text: 'var(--text-secondary)' },
    rest:     { background: 'transparent', glyph: 'var(--text-secondary)', text: 'var(--text-meta)' },
    hover:    { background: 'var(--sunken)', glyph: 'var(--text-primary)', text: 'var(--text-secondary)' },
    disabled: { background: 'transparent', glyph: 'var(--text-disabled)', text: 'var(--text-disabled)' }
  }[state];
  return (
    <div onClick={state === 'disabled' ? undefined : onClick}
      style={{ width: 48, padding: '9px 0', borderRadius: 'var(--radius-md)', display: 'flex', flexDirection: 'column',
        alignItems: 'center', gap: 5, position: 'relative', background: looks.background,
        cursor: state === 'disabled' ? 'not-allowed' : 'pointer', fontFamily: 'var(--font-ui)', ...style }}>
      {state === 'active' && <span style={{ position: 'absolute', left: -8, top: 10, bottom: 10, width: 2, background: 'var(--green)', borderRadius: 2 }} />}
      <span style={{ fontSize: 15, color: looks.glyph }}>{glyph}</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: looks.text }}>{label}</span>
    </div>
  );
}
