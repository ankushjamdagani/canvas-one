Integer stepper for attempt counts and the like.

```jsx
<Stepper value={5} onChange={setAttempts} />
```
