import React from 'react';

export function Stepper({ value = 5, onChange, style }) {
  const arm = { width: 28, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-body)', cursor: 'pointer', userSelect: 'none' };
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', background: 'var(--canvas-white)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-control)', overflow: 'hidden', fontFamily: 'var(--font-ui)', ...style }}>
      <span style={{ ...arm, borderRight: '1px solid var(--hairline-soft)' }} onClick={() => onChange && onChange(value - 1)}>−</span>
      <span style={{ minWidth: 44, textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: 12 }}>{value}</span>
      <span style={{ ...arm, borderLeft: '1px solid var(--hairline-soft)' }} onClick={() => onChange && onChange(value + 1)}>＋</span>
    </span>
  );
}
