Radio.

```jsx
<Radio label="Exponential" checked />
```
