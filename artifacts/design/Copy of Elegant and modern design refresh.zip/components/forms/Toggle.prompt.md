Switch for immediate settings.

```jsx
<Toggle label="Jitter" on />
```
