Slider for continuous values; always pair it with a mono readout.

```jsx
<Slider percent={62} readout="620ms" />
```
