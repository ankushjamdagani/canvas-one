/** Track + thumb with a mono readout. */
export interface SliderProps { percent?: number; readout?: string; width?: number; style?: React.CSSProperties; }
export function Slider(props: SliderProps): JSX.Element;
