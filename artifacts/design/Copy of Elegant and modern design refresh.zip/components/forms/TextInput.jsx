import React from 'react';

export function TextInput({ value, placeholder = 'Part name', state = 'rest', hint, onChange, style }) {
  const looks = {
    rest:     { background: 'var(--shell)', border: '1px solid var(--border)', boxShadow: 'none' },
    hover:    { background: 'var(--canvas-white)', border: '1px solid var(--border-strong)', boxShadow: 'none' },
    focused:  { background: 'var(--canvas-white)', border: '1px solid var(--green)', boxShadow: 'var(--ring-soft)' },
    filled:   { background: 'var(--canvas-white)', border: '1px solid var(--border)', boxShadow: 'none' },
    error:    { background: 'var(--canvas-white)', border: '1px solid var(--clay)', boxShadow: 'var(--ring-danger-soft)' },
    disabled: { background: 'var(--panel)', border: '1px solid var(--hairline)', boxShadow: 'none' }
  }[state];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 7, ...style }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, borderRadius: 'var(--radius-control)', padding: '8px 10px', ...looks }}>
        <input value={value} placeholder={placeholder} disabled={state === 'disabled'} onChange={e => onChange && onChange(e.target.value)}
          style={{ flex: 1, minWidth: 0, border: 'none', outline: 'none', background: 'transparent', fontFamily: 'var(--font-ui)',
            fontSize: 12.5, color: state === 'disabled' ? 'var(--text-disabled)' : 'var(--text-primary)' }} />
        {state === 'error' && <span style={{ fontSize: 12, color: 'var(--clay)' }}>!</span>}
      </div>
      {hint && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: state === 'error' ? 'var(--clay)' : 'var(--text-meta)' }}>{hint}</span>}
    </div>
  );
}
