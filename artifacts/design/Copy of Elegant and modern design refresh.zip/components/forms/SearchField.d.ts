/** Panel search field; shows its keyboard shortcut until it has a value. */
export interface SearchFieldProps {
  value?: string; placeholder?: string; active?: boolean; shortcut?: string;
  onChange?: (value: string) => void; onClear?: () => void; style?: React.CSSProperties;
}
export function SearchField(props: SearchFieldProps): JSX.Element;
