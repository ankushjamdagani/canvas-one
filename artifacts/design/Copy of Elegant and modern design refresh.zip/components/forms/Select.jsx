import React from 'react';

export function Select({ value, options = [], open, onSelect, onToggle, style }) {
  const trigger = (
    <div onClick={onToggle} style={{ display: 'flex', alignItems: 'center', gap: 8, background: open ? 'var(--shell)' : 'var(--canvas-white)',
      border: '1px solid var(--border)', borderRadius: open ? 'var(--radius-node) var(--radius-node) 0 0' : 'var(--radius-control)',
      padding: '8px 10px', cursor: 'pointer', borderBottom: open ? '1px solid var(--hairline-soft)' : undefined }}>
      <span style={{ fontSize: 12.5 }}>{value}</span>
      <span style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--text-meta)' }}>{open ? '▴' : '▾'}</span>
    </div>
  );
  if (!open) return <div style={{ fontFamily: 'var(--font-ui)', ...style }}>{trigger}</div>;
  return (
    <div style={{ fontFamily: 'var(--font-ui)', background: 'var(--canvas-white)', border: '1px solid var(--border)',
      borderRadius: 'var(--radius-node)', boxShadow: 'var(--shadow-popover)', overflow: 'hidden', ...style }}>
      {trigger}
      <div style={{ padding: 5, display: 'flex', flexDirection: 'column', gap: 1 }}>
        {options.map(o => {
          const label = typeof o === 'string' ? o : o.label;
          const disabled = typeof o === 'object' && o.disabled;
          const on = label === value;
          return (
            <div key={label} onClick={() => !disabled && onSelect && onSelect(label)}
              style={{ padding: '7px 9px', borderRadius: 'var(--radius-sm)', fontSize: 12.5, display: 'flex', gap: 8,
                cursor: disabled ? 'not-allowed' : 'pointer',
                background: on ? 'var(--green-tint)' : 'transparent',
                color: disabled ? 'var(--text-disabled)' : on ? 'var(--green)' : 'var(--text-primary)' }}>
              <span>{label}</span>{on && <span style={{ marginLeft: 'auto' }}>✓</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
