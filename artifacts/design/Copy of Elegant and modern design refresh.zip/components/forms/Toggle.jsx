import React from 'react';

export function Toggle({ label, on, disabled, onChange, style }) {
  return (
    <label onClick={() => !disabled && onChange && onChange(!on)}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12.5, fontFamily: 'var(--font-ui)',
        color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)', cursor: disabled ? 'not-allowed' : 'pointer', ...style }}>
      <span style={{ width: 34, height: 20, borderRadius: 20, display: 'flex', alignItems: 'center', padding: '0 2px', boxSizing: 'border-box',
        justifyContent: on ? 'flex-end' : 'flex-start',
        background: disabled ? 'var(--sunken)' : on ? 'var(--green)' : '#E2DED6',
        border: on && !disabled ? 'none' : `1px solid ${disabled ? 'var(--hairline)' : 'var(--border)'}` }}>
        <span style={{ width: 14, height: 14, borderRadius: '50%', background: disabled ? 'var(--hairline)' : 'var(--canvas-white)',
          boxShadow: disabled ? 'none' : '0 1px 2px rgba(22,32,29,0.2)' }} />
      </span>
      {label}
    </label>
  );
}
