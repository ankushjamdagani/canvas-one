Checkbox.

```jsx
<Checkbox label="Include archived" state="mixed" />
```
