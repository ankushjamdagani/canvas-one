/** Radio button. */
export interface RadioProps { label?: string; checked?: boolean; disabled?: boolean; onChange?: (v: boolean) => void; style?: React.CSSProperties; }
export function Radio(props: RadioProps): JSX.Element;
