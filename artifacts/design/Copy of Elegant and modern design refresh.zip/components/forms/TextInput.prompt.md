Text field. Rest sits on shell; once touched it goes white.

```jsx
<TextInput value="retry worker" state="error" hint="NAME TAKEN" />
```
