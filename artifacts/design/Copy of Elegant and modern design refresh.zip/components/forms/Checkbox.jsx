import React from 'react';

export function Checkbox({ label, state = 'off', focused, onChange, style }) {
  const on = state === 'on' || state === 'mixed';
  const disabled = state === 'disabled';
  return (
    <label onClick={() => !disabled && onChange && onChange(state === 'on' ? 'off' : 'on')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12.5, fontFamily: 'var(--font-ui)',
        color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)', cursor: disabled ? 'not-allowed' : 'pointer', ...style }}>
      <span style={{ width: 16, height: 16, borderRadius: 'var(--radius-tag)', display: 'flex', alignItems: 'center', justifyContent: 'center',
        border: `1px solid ${disabled ? 'var(--hairline)' : on ? 'var(--green)' : 'var(--border-strong)'}`,
        background: disabled ? 'var(--panel)' : on ? 'var(--green)' : 'var(--canvas-white)',
        boxShadow: focused ? 'var(--ring)' : 'none', color: 'var(--text-on-green)', fontSize: 10 }}>
        {state === 'on' && '✓'}
        {state === 'mixed' && <span style={{ width: 8, height: 2, background: 'var(--text-on-green)' }} />}
      </span>
      {label}
    </label>
  );
}
