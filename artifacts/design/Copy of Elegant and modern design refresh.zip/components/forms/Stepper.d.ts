/** Numeric stepper; the value reads in mono. */
export interface StepperProps { value?: number; onChange?: (v: number) => void; style?: React.CSSProperties; }
export function Stepper(props: StepperProps): JSX.Element;
