import React from 'react';

export function Slider({ percent = 62, readout, width = 200, style }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, width, fontFamily: 'var(--font-ui)', ...style }}>
      <span style={{ flex: 1, height: 4, borderRadius: 4, background: '#E2DED6', position: 'relative' }}>
        <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: percent + '%', background: 'var(--green)', borderRadius: 4 }} />
        <span style={{ position: 'absolute', left: percent + '%', top: '50%', width: 14, height: 14, margin: '-7px 0 0 -7px', borderRadius: '50%',
          background: 'var(--canvas-white)', border: '1px solid var(--green)', boxShadow: '0 1px 3px rgba(22,32,29,0.22)' }} />
      </span>
      {readout && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-secondary)' }}>{readout}</span>}
    </span>
  );
}
