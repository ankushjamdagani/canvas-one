Search row at the top of a panel.

```jsx
<SearchField value="retry" active onClear={clear} />
```
