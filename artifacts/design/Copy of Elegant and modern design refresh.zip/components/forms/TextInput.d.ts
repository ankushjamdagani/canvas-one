/** Single-line field in the six states the studio draws. */
export interface TextInputProps {
  value?: string;
  placeholder?: string;
  state?: 'rest' | 'hover' | 'focused' | 'filled' | 'error' | 'disabled';
  /** mono caption under the field — the reason, especially on error and disabled */
  hint?: string;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}
export function TextInput(props: TextInputProps): JSX.Element;
