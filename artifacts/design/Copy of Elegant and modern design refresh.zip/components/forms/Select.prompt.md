Select with an attached popover list.

```jsx
<Select value="Exponential" open options={['Exponential','Linear',{label:'Custom curve',disabled:true}]} />
```
