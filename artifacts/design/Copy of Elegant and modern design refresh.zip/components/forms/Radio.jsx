import React from 'react';

export function Radio({ label, checked, disabled, onChange, style }) {
  return (
    <label onClick={() => !disabled && onChange && onChange(true)}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12.5, fontFamily: 'var(--font-ui)',
        color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)', cursor: disabled ? 'not-allowed' : 'pointer', ...style }}>
      <span style={{ width: 16, height: 16, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
        border: `1px solid ${disabled ? 'var(--hairline)' : checked ? 'var(--green)' : 'var(--border-strong)'}`,
        background: disabled ? 'var(--panel)' : 'var(--canvas-white)' }}>
        {checked && <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--green)' }} />}
      </span>
      {label}
    </label>
  );
}
