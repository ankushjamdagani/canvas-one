import React from 'react';

export function SearchField({ value, placeholder = 'Search the library', active, shortcut = 'P', onChange, onClear, style }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--panel)',
      border: `1px solid ${active ? 'var(--green)' : 'var(--border)'}`, boxShadow: active ? 'var(--ring-soft)' : 'none',
      borderRadius: 'var(--radius-control)', padding: '7px 9px', ...style }}>
      <span style={{ fontSize: 11, color: active ? 'var(--green)' : 'var(--text-meta)' }}>⌕</span>
      <input value={value} placeholder={placeholder} onChange={e => onChange && onChange(e.target.value)}
        style={{ flex: 1, minWidth: 0, border: 'none', outline: 'none', background: 'transparent', fontFamily: 'var(--font-ui)', fontSize: 12.5, color: 'var(--text-primary)' }} />
      {value ? <span onClick={onClear} style={{ fontSize: 11, color: 'var(--text-meta)', cursor: 'pointer' }}>✕</span>
             : <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: 'var(--text-placeholder)' }}>{shortcut}</span>}
    </div>
  );
}
