/** 34×20 switch. */
export interface ToggleProps { label?: string; on?: boolean; disabled?: boolean; onChange?: (v: boolean) => void; style?: React.CSSProperties; }
export function Toggle(props: ToggleProps): JSX.Element;
