/** Checkbox with the mixed state used by library section headers. */
export interface CheckboxProps {
  label?: string;
  state?: 'off' | 'on' | 'mixed' | 'disabled';
  focused?: boolean;
  onChange?: (next: 'on' | 'off') => void;
  style?: React.CSSProperties;
}
export function Checkbox(props: CheckboxProps): JSX.Element;
