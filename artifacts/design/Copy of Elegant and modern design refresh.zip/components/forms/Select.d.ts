/** Dropdown; when open the trigger becomes the head of the popover. */
export interface SelectProps {
  value?: string;
  options?: (string | { label: string; disabled?: boolean })[];
  open?: boolean;
  onSelect?: (label: string) => void;
  onToggle?: () => void;
  style?: React.CSSProperties;
}
export function Select(props: SelectProps): JSX.Element;
