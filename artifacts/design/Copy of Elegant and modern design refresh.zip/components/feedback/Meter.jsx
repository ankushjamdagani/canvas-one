import React from 'react';

export function Meter({ label, percent = 38, readout, tone = 'green', style }) {
  const c = tone === 'clay' ? 'var(--clay)' : 'var(--green)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'var(--font-ui)', ...style }}>
      {label && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, color: 'var(--text-meta)', width: 74 }}>{label}</span>}
      <span style={{ flex: 1, height: 6, borderRadius: 6, background: 'var(--sunken)', overflow: 'hidden' }}>
        <span style={{ display: 'block', width: percent + '%', height: '100%', background: c }} />
      </span>
      {readout && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: tone === 'clay' ? 'var(--clay)' : 'var(--text-body)' }}>{readout}</span>}
    </div>
  );
}
