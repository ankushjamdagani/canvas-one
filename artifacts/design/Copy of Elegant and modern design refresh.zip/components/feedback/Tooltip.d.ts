/** Ink tooltip; carries the shortcut when there is one. */
export interface TooltipProps { label?: string; shortcut?: string; style?: React.CSSProperties; }
export function Tooltip(props: TooltipProps): JSX.Element;
