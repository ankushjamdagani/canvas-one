import React from 'react';

const TONES = {
  risk:   { edge: 'var(--clay-edge)', spine: 'var(--clay)' },
  branch: { edge: 'var(--purple-edge)', spine: 'var(--purple)' },
  done:   { edge: 'var(--green-edge)', spine: 'var(--green)' }
};

export function InlineAlert({ tone = 'risk', title, detail, glyph, children, style }) {
  const t = TONES[tone] || TONES.risk;
  return (
    <div style={{ background: 'var(--canvas-white)', border: `1px solid ${t.edge}`, borderLeft: `3px solid ${t.spine}`,
      borderRadius: 'var(--radius-panel)', padding: '11px 13px', display: 'flex', alignItems: 'center', gap: 11,
      boxShadow: tone === 'risk' ? '0 2px 6px rgba(22,32,29,0.05)' : 'none', fontFamily: 'var(--font-ui)', ...style }}>
      {glyph && <span style={{ fontSize: 12, color: t.spine }}>{glyph}</span>}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12.5, fontWeight: 600 }}>{title}</div>
        {detail && <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2 }}>{detail}</div>}
      </div>
      {children}
    </div>
  );
}
