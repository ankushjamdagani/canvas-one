Tooltip.

```jsx
<Tooltip label="Fit to canvas" shortcut="⇧1" />
```
