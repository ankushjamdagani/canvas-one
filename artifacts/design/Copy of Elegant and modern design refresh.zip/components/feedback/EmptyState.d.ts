/** Dashed-outline empty panel state; always offers the next move. */
export interface EmptyStateProps { glyph?: string; title?: string; detail?: string; children?: React.ReactNode; style?: React.CSSProperties; }
export function EmptyState(props: EmptyStateProps): JSX.Element;
