import React from 'react';

export function Tooltip({ label, shortcut, style }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 9, background: 'var(--ink)', color: 'var(--text-on-ink)',
      borderRadius: 'var(--radius-control)', padding: '6px 9px', fontSize: 12, fontFamily: 'var(--font-ui)', ...style }}>
      {label}{shortcut && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: '#9BA8A3' }}>{shortcut}</span>}
    </span>
  );
}
