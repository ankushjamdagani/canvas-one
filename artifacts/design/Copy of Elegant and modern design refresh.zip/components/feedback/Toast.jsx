import React from 'react';

export function Toast({ message, action, onAction, style }) {
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 14, background: 'var(--ink)', color: 'var(--text-on-ink)',
      borderRadius: 'var(--radius-panel)', padding: '10px 14px', boxShadow: 'var(--shadow-toast)', fontFamily: 'var(--font-ui)', ...style }}>
      <span style={{ fontSize: 12.5 }}>{message}</span>
      {action && <span onClick={onAction} style={{ fontSize: 12, color: 'var(--green-edge-strong)', cursor: 'pointer' }}>{action}</span>}
    </div>
  );
}
