Inline notice. Risk = clay, branch = purple, done = green. Actions go on the right.

```jsx
<InlineAlert tone="risk" title="Run 13 is unsaved" detail="Switching to main will discard it.">
  <Button tone="ghost" size="small">Discard</Button>
  <Button size="small">Save, then switch</Button>
</InlineAlert>
```
