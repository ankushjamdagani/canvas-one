import React from 'react';

export function EmptyState({ glyph = '⊞', title, detail, children, style }) {
  return (
    <div style={{ border: '1px dashed var(--border)', borderRadius: 'var(--radius-node)', padding: '22px 16px', textAlign: 'center',
      display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'center', fontFamily: 'var(--font-ui)', ...style }}>
      <span style={{ fontSize: 18, color: 'var(--text-disabled)' }}>{glyph}</span>
      <span style={{ fontSize: 12.5, fontWeight: 600 }}>{title}</span>
      {detail && <span style={{ fontSize: 12, color: 'var(--text-secondary)', maxWidth: 230, lineHeight: 1.5 }}>{detail}</span>}
      {children}
    </div>
  );
}
