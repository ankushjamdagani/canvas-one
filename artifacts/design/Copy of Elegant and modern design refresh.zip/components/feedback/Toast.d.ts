/** Dark transient message that floats over the canvas. */
export interface ToastProps { message?: string; action?: string; onAction?: () => void; style?: React.CSSProperties; }
export function Toast(props: ToastProps): JSX.Element;
