Canvas toast — ink fill, one optional action in pale green.

```jsx
<Toast message="Simulation finished · 1,204 requests" action="View runs" />
```
