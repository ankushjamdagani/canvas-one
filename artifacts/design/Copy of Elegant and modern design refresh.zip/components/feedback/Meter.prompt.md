Metric bar. Clay tone only when the number is bad.

```jsx
<Meter label="ERROR RATE" percent={81} readout="8.1%" tone="clay" />
```
