/** Labelled 6px bar for queue depth, error rate and similar readings. */
export interface MeterProps { label?: string; percent?: number; readout?: string; tone?: 'green' | 'clay'; style?: React.CSSProperties; }
export function Meter(props: MeterProps): JSX.Element;
