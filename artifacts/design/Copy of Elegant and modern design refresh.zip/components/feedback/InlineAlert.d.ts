/**
 * In-flow notice with a 3px coloured spine.
 * @startingPoint section="Feedback" subtitle="Risk, branch and done notices" viewport="700x200"
 */
export interface InlineAlertProps {
  tone?: 'risk' | 'branch' | 'done';
  title?: string; detail?: string; glyph?: string;
  /** trailing actions — Buttons or plain text links */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export function InlineAlert(props: InlineAlertProps): JSX.Element;
