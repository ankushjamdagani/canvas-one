Empty state inside a panel.

```jsx
<EmptyState title="Nothing matches “retry”" detail="Clear the filter, or save the current selection as a new part.">
  <Button size="small">Save selection as part</Button>
</EmptyState>
```
