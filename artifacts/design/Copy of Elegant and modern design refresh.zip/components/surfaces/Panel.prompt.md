Panel shell for History and the Components Library.

```jsx
<Panel title="Library" tag={<Tag tone="green">FROM DOCK</Tag>} actions={<IconButton glyph="⊞" size={22}/>}>
  …rows…
</Panel>
```

Placement control lives in the header, never in settings. A single docked panel with tabs uses the tab strip as its header instead.
