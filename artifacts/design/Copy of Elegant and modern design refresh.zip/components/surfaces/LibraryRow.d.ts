/**
 * A saved part in the Components Library, in every list state including drag and skeleton.
 * @startingPoint section="Surfaces" subtitle="Library list row in all states" viewport="700x260"
 */
export interface LibraryRowProps {
  title?: string; meta?: string; glyph?: string;
  state?: 'rest' | 'hover' | 'selected' | 'dragging' | 'disabled' | 'loading';
  trailing?: React.ReactNode;
  style?: React.CSSProperties;
}
export function LibraryRow(props: LibraryRowProps): JSX.Element;
