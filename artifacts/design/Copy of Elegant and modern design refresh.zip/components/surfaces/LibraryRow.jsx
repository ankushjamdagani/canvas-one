import React from 'react';

export function LibraryRow({ title, meta, glyph = '⧉', state = 'rest', trailing, style }) {
  const looks = {
    rest:     { background: 'var(--shell)', border: '1px solid var(--hairline)', boxShadow: 'none' },
    hover:    { background: 'var(--canvas-white)', border: '1px solid var(--border)', boxShadow: 'var(--shadow-raised)' },
    selected: { background: 'var(--canvas-white)', border: '1px solid var(--green)', boxShadow: 'var(--ring-soft)' },
    dragging: { background: 'var(--canvas-white)', border: '1px dashed var(--green)', boxShadow: '0 18px 30px -18px rgba(22,32,29,0.4)', transform: 'rotate(-0.6deg)' },
    disabled: { background: 'var(--panel)', border: '1px solid var(--hairline-soft)', boxShadow: 'none' },
    loading:  { background: 'var(--shell)', border: '1px solid var(--hairline)', boxShadow: 'none' }
  }[state];
  const accent = state === 'selected' || state === 'dragging';
  const off = state === 'disabled';
  if (state === 'loading') {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 9px', borderRadius: 'var(--radius-md)', ...looks, ...style }}>
        <span style={{ width: 26, height: 26, flex: '0 0 26px', borderRadius: 'var(--radius-control)', background: 'var(--sunken)' }} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <span style={{ width: '52%', height: 9, borderRadius: 4, background: 'var(--hairline-soft)' }} />
          <span style={{ width: '34%', height: 7, borderRadius: 4, background: 'var(--sunken)' }} />
        </div>
      </div>
    );
  }
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 9px', borderRadius: 'var(--radius-md)',
      fontFamily: 'var(--font-ui)', cursor: off ? 'not-allowed' : 'pointer', ...looks, ...style }}>
      <span style={{ width: 26, height: 26, flex: '0 0 26px', borderRadius: 'var(--radius-control)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12,
        background: accent ? 'var(--green-tint)' : 'var(--sunken)',
        border: `1px solid ${accent ? 'var(--green-edge)' : off ? 'var(--hairline)' : 'var(--border)'}`,
        color: accent ? 'var(--green)' : off ? 'var(--text-disabled)' : 'var(--text-body)' }}>{glyph}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: off ? 'var(--text-disabled)' : state === 'dragging' ? 'var(--green)' : 'var(--text-primary)' }}>{title}</div>
        {meta && <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9.5, marginTop: 2, color: off ? 'var(--text-disabled)' : state === 'dragging' ? '#6B8F87' : 'var(--text-meta)' }}>{meta}</div>}
      </div>
      {trailing}
    </div>
  );
}
