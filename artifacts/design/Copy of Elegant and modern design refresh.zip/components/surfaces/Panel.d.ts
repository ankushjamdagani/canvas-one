/**
 * Side or floating panel shell. The header doubles as the drag handle.
 * @startingPoint section="Surfaces" subtitle="Docked or floating panel with header" viewport="700x360"
 */
export interface PanelProps {
  title?: string;
  /** a <Tag> marking provenance, e.g. FROM DOCK */
  tag?: React.ReactNode;
  /** header-right controls — placement ⊞, collapse, close */
  actions?: React.ReactNode;
  placement?: 'right' | 'left' | 'floating';
  width?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export function Panel(props: PanelProps): JSX.Element;
