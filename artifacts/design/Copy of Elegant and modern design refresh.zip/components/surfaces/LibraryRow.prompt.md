Library row.

```jsx
<LibraryRow title="Retry envelope" meta="queue + worker + dlq" state="selected" />
```

`dragging` is the tilted dashed ghost that follows the cursor onto the canvas; `loading` renders the skeleton.
