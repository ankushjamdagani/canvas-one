import React from 'react';

const FILLS = ['var(--green)', 'var(--purple)', '#E2DED6'];

export function AvatarStack({ people = [], overflow, label, style }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'var(--font-ui)', ...style }}>
      <span style={{ display: 'flex' }}>
        {people.map((p, i) => (
          <span key={i} style={{ width: 26, height: 26, borderRadius: '50%', background: FILLS[i % FILLS.length],
            color: i === 2 ? 'var(--text-body)' : 'var(--text-on-green)', fontSize: 10.5, fontWeight: 600,
            display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid var(--canvas-white)',
            marginLeft: i ? -8 : 0 }}>{p}</span>
        ))}
        {overflow != null && <span style={{ width: 26, height: 26, borderRadius: '50%', background: '#E2DED6', color: 'var(--text-body)',
          fontSize: 10.5, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid var(--canvas-white)', marginLeft: -8 }}>+{overflow}</span>}
      </span>
      {label && <span style={{ fontSize: 12.5, color: 'var(--text-secondary)' }}>{label}</span>}
    </div>
  );
}
