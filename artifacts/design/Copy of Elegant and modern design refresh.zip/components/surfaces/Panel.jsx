import React from 'react';

export function Panel({ title, tag, actions, placement = 'right', width = 300, children, style }) {
  const edge = placement === 'left' ? { borderRight: '1px solid var(--hairline)' } : placement === 'right' ? { borderLeft: '1px solid var(--hairline)' } : {};
  const floating = placement === 'floating';
  return (
    <div style={{ width, display: 'flex', flexDirection: 'column', background: 'var(--canvas-white)', fontFamily: 'var(--font-ui)',
      border: floating ? '1px solid var(--border)' : undefined, borderRadius: floating ? 'var(--radius-card)' : 0,
      boxShadow: floating ? 'var(--shadow-floating)' : 'none', overflow: 'hidden', ...edge, ...style }}>
      <div style={{ padding: '12px 14px', borderBottom: '1px solid var(--hairline)', display: 'flex', alignItems: 'center', gap: 9, cursor: 'grab' }}>
        <span style={{ fontSize: 14, fontWeight: 600 }}>{title}</span>
        {tag}
        <span style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>{actions}</span>
      </div>
      <div style={{ flex: 1, minHeight: 0, overflow: 'auto', padding: 14, display: 'flex', flexDirection: 'column', gap: 9 }}>{children}</div>
    </div>
  );
}
