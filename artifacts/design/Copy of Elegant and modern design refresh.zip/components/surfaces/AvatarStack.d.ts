/** Overlapping initials for the people on a document. */
export interface AvatarStackProps { people?: string[]; overflow?: number; label?: string; style?: React.CSSProperties; }
export function AvatarStack(props: AvatarStackProps): JSX.Element;
