Presence stack. Initials only — the system has no avatar imagery.

```jsx
<AvatarStack people={['RK','MA']} overflow={4} label="Platform team" />
```
