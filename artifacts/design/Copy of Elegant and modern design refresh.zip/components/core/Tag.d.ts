/** Mono uppercase status tag. */
export interface TagProps {
  children?: React.ReactNode;
  tone?: 'green' | 'purple' | 'clay' | 'neutral' | 'ink';
  style?: React.CSSProperties;
}
export function Tag(props: TagProps): JSX.Element;
