import React from 'react';

export function IconButton({ glyph, state = 'rest', size = 32, title, onClick, style }) {
  const looks = {
    rest:     { color: 'var(--text-body)', background: 'transparent', border: '1px solid transparent' },
    hover:    { color: 'var(--text-primary)', background: 'var(--sunken)', border: '1px solid transparent' },
    active:   { color: 'var(--green)', background: 'var(--green-tint)', border: '1px solid var(--green-edge)' },
    selected: { color: 'var(--text-on-ink)', background: 'var(--ink)', border: '1px solid var(--ink)' },
    disabled: { color: 'var(--text-disabled)', background: 'transparent', border: '1px solid transparent' }
  }[state];
  return (
    <button type="button" title={title} onClick={onClick} disabled={state === 'disabled'}
      style={{ width: size, height: size, display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 'var(--radius-md)', fontSize: Math.round(size * 0.47), fontFamily: 'var(--font-ui)',
        cursor: state === 'disabled' ? 'not-allowed' : 'pointer', ...looks, ...style }}>{glyph}</button>
  );
}
