import React from 'react';

export function KeyHint({ children, style }) {
  return <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-body)', background: 'var(--panel)',
    border: '1px solid var(--border)', borderBottomWidth: 2, borderRadius: 5, padding: '3px 7px', ...style }}>{children}</span>;
}
