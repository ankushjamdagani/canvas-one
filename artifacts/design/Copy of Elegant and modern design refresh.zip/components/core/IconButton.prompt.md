32px square glyph button — the dock, panel headers and rails are built from these.

```jsx
<IconButton glyph="↺" title="Undo" />
<IconButton glyph="⊞" state="selected" />
```

`active` is the green tinted "tool is on" look; `selected` is the ink fill used for the dock's placement tool.
