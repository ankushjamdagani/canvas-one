/** Keycap for shortcut hints; the 2px bottom border is the keycap cue. */
export interface KeyHintProps { children?: React.ReactNode; style?: React.CSSProperties; }
export function KeyHint(props: KeyHintProps): JSX.Element;
