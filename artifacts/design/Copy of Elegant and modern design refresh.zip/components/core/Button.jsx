import React from 'react';

const TONES = {
  primary:     { bg: 'var(--green)', fg: 'var(--text-on-green)', bd: 'transparent', weight: 600 },
  secondary:   { bg: 'var(--sunken)', fg: 'var(--text-primary)', bd: 'var(--border-strong)', weight: 600 },
  tint:        { bg: 'var(--green-tint)', fg: 'var(--green)', bd: 'var(--green-edge)', weight: 500 },
  ghost:       { bg: 'transparent', fg: 'var(--text-body)', bd: 'transparent', weight: 500 },
  destructive: { bg: 'var(--clay)', fg: 'var(--text-on-green)', bd: 'transparent', weight: 600 }
};
const SIZES = {
  small:  { font: 11.5, pad: '6px 11px', radius: 'var(--radius-sm)' },
  medium: { font: 13,   pad: '8px 16px', radius: 'var(--radius-control)' },
  large:  { font: 14,   pad: '11px 20px', radius: 'var(--radius-md)' }
};

export function Button({ children, tone = 'primary', size = 'medium', disabled, working, focused, glyph, shortcut, onClick, style }) {
  const t = TONES[tone] || TONES.primary;
  const s = SIZES[size] || SIZES.medium;
  const danger = tone === 'destructive';
  const base = {
    display: 'inline-flex', alignItems: 'center', gap: 7,
    font: `${t.weight} ${s.font}px var(--font-ui)`,
    color: disabled ? (tone === 'primary' || danger ? '#A3ABA6' : 'var(--text-disabled)') : t.fg,
    background: disabled ? (tone === 'ghost' ? 'transparent' : tone === 'primary' || danger ? 'var(--hairline)' : 'var(--panel)') : t.bg,
    border: `1px solid ${disabled ? (tone === 'ghost' ? 'transparent' : 'var(--hairline)') : t.bd}`,
    borderRadius: s.radius, padding: s.pad,
    cursor: disabled ? 'not-allowed' : working ? 'progress' : 'pointer',
    boxShadow: focused ? (danger ? 'var(--ring-danger)' : tone === 'primary' ? 'var(--ring-strong)' : 'var(--ring)') : 'none',
    ...style
  };
  if (focused && !danger && tone !== 'primary') base.borderColor = 'var(--green)';
  return (
    <button type="button" style={base} disabled={disabled} onClick={onClick}>
      {working && <span style={{ width: 11, height: 11, borderRadius: '50%', border: '2px solid rgba(251,250,247,0.35)', borderTopColor: 'currentColor', display: 'inline-block' }} />}
      {glyph && !working && <span style={{ fontSize: s.font - 3 }}>{glyph}</span>}
      {children}
      {shortcut && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-meta)', marginLeft: 3 }}>{shortcut}</span>}
    </button>
  );
}
