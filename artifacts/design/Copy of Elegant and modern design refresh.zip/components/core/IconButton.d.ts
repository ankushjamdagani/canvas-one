/** Square 32px glyph button used across the dock, panel headers and rails. */
export interface IconButtonProps {
  /** unicode glyph, e.g. "↺" "⊞" "⋯" */
  glyph: string;
  state?: 'rest' | 'hover' | 'active' | 'selected' | 'disabled';
  size?: number;
  title?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export function IconButton(props: IconButtonProps): JSX.Element;
