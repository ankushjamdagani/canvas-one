Text button; use `primary` for the one filled green action on a surface and everything else for the rest.

```jsx
<Button tone="primary" glyph="▶">Run simulation</Button>
<Button tone="secondary" shortcut="⌘K">Quick options</Button>
```

Tones: primary (filled green), secondary (stone fill + border), tint (green wash, used for panel-level actions), ghost (chrome-level), destructive (clay). Sizes small/medium/large. `working` shows the spinner; primary and secondary are the only tones with a working state.
