System state dot.

```jsx
<StatusDot status="live" label="Live" halo />
```
