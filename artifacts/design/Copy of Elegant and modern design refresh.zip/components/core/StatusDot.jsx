import React from 'react';

const C = { live: 'var(--green)', degraded: 'var(--clay)', idle: 'var(--text-disabled)', branch: 'var(--purple)' };

export function StatusDot({ status = 'live', label, halo, style }) {
  const dot = <span style={{ width: 8, height: 8, borderRadius: '50%', background: C[status],
    boxShadow: halo ? `0 0 0 3px ${status === 'live' ? 'rgba(11,92,84,0.14)' : 'rgba(180,103,74,0.14)'}` : 'none' }} />;
  if (!label) return dot;
  return <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7, fontSize: 12.5, fontFamily: 'var(--font-ui)', ...style }}>{dot}{label}</span>;
}
