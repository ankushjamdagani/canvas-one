import React from 'react';

const TONES = {
  green:   ['var(--green)', 'var(--green-tint)', 'var(--green-edge)'],
  purple:  ['var(--purple)', 'var(--purple-tint)', 'var(--purple-edge)'],
  clay:    ['var(--clay)', 'var(--clay-tint)', 'var(--clay-edge)'],
  neutral: ['var(--text-body)', 'var(--sunken)', 'var(--border)'],
  ink:     ['var(--text-on-ink)', 'var(--ink)', 'var(--ink)']
};

export function Tag({ children, tone = 'neutral', style }) {
  const [fg, bg, bd] = TONES[tone] || TONES.neutral;
  return <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, letterSpacing: '0.1em', color: fg,
    background: bg, border: `1px solid ${bd}`, borderRadius: 'var(--radius-tag)', padding: '2px 7px', ...style }}>{children}</span>;
}
