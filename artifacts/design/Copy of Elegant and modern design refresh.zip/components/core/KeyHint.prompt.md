Keycap.

```jsx
<KeyHint>⌘K</KeyHint>
```
