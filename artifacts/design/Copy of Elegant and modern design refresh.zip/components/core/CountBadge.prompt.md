Count pill. Accent only on the active tab.

```jsx
<CountBadge tone="accent">48</CountBadge>
```
