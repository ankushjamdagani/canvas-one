/** 8px state dot, optionally with a halo and a label. */
export interface StatusDotProps {
  status?: 'live' | 'degraded' | 'idle' | 'branch';
  label?: string;
  halo?: boolean;
  style?: React.CSSProperties;
}
export function StatusDot(props: StatusDotProps): JSX.Element;
