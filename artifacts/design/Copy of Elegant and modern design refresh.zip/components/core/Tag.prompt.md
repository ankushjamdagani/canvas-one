Small mono tag for provenance and state. Always uppercase.

```jsx
<Tag tone="green">FROM DOCK</Tag>
<Tag tone="clay">UNSAVED</Tag>
```

Green = provenance/live, purple = branch, clay = risk/unsaved, neutral = draft, ink = published.
