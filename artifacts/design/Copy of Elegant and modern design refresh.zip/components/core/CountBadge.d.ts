/** Mono pill count that rides beside tab and section labels. */
export interface CountBadgeProps {
  children?: React.ReactNode;
  tone?: 'accent' | 'neutral';
  style?: React.CSSProperties;
}
export function CountBadge(props: CountBadgeProps): JSX.Element;
