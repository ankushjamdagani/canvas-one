/**
 * The studio's text button in all five tones.
 * @startingPoint section="Core" subtitle="Five tones, three sizes, every state" viewport="700x220"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** primary is the single filled green action per surface */
  tone?: 'primary' | 'secondary' | 'tint' | 'ghost' | 'destructive';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  /** shows the inline spinner and the progress cursor */
  working?: boolean;
  /** static focus-ring rendering, for specimens */
  focused?: boolean;
  /** leading unicode glyph, e.g. "▶" */
  glyph?: string;
  /** trailing mono shortcut, e.g. "⌘K" */
  shortcut?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export function Button(props: ButtonProps): JSX.Element;
