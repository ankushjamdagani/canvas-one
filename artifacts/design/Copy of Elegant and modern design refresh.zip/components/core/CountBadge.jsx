import React from 'react';

export function CountBadge({ children, tone = 'neutral', style }) {
  const on = tone === 'accent';
  return <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, borderRadius: 'var(--radius-pill)', padding: '2px 8px',
    color: on ? 'var(--text-on-green)' : 'var(--text-body)', background: on ? 'var(--green)' : 'var(--sunken)', ...style }}>{children}</span>;
}
