const { useState } = React;

const C = {
  ink:'var(--ink)', green:'var(--green)', tint:'var(--green-tint)', edge:'var(--green-edge)',
  border:'var(--border)', hair:'var(--hairline)', meta:'var(--text-meta)', body:'var(--text-body)'
};
const mono = { fontFamily:'var(--font-mono)' };

function Icon({ glyph, state='rest', size=32, onClick, title }) {
  const looks = {
    rest:{color:'var(--text-body)',background:'transparent',border:'1px solid transparent'},
    active:{color:'var(--green)',background:'var(--green-tint)',border:'1px solid var(--green-edge)'},
    selected:{color:'var(--text-on-ink)',background:'var(--ink)',border:'1px solid var(--ink)'},
    disabled:{color:'var(--text-disabled)',background:'transparent',border:'1px solid transparent'}
  }[state];
  return <button title={title} onClick={state==='disabled'?undefined:onClick}
    style={{width:size,height:size,display:'flex',alignItems:'center',justifyContent:'center',borderRadius:8,
      fontSize:Math.round(size*0.47),cursor:state==='disabled'?'not-allowed':'pointer',...looks}}>{glyph}</button>;
}

function Tag({ children, tone='neutral' }) {
  const T={green:['var(--green)','var(--green-tint)','var(--green-edge)'],purple:['var(--purple)','var(--purple-tint)','var(--purple-edge)'],
    clay:['var(--clay)','var(--clay-tint)','var(--clay-edge)'],neutral:['var(--text-body)','var(--sunken)','var(--border)']}[tone];
  return <span style={{...mono,fontSize:9,letterSpacing:'0.1em',color:T[0],background:T[1],border:'1px solid '+T[2],borderRadius:4,padding:'2px 7px'}}>{children}</span>;
}

function NodeCard({ node, selected, onSelect }) {
  const stripe = { service:'var(--green)', queue:'var(--purple)', store:'var(--clay)', pattern:'var(--green)' }[node.kind];
  return (
    <div onClick={() => onSelect(node.id)}
      style={{position:'absolute',left:node.x,top:node.y,width:176,boxSizing:'border-box',background:'var(--canvas-white)',
        border:selected?'1px solid var(--green)':node.alerting?'1px solid var(--clay)':'1px solid var(--border)',
        boxShadow:selected?'0 0 0 3px rgba(11,92,84,0.14)':node.alerting?'var(--ring-danger-soft)':'none',
        borderRadius:9,cursor:'pointer'}}>
      <div style={{height:3,background:stripe,borderRadius:'8px 8px 0 0'}}></div>
      <div style={{padding:'10px 12px'}}>
        <div style={{fontSize:13,fontWeight:600}}>{node.title}</div>
        <div style={{...mono,fontSize:9.5,marginTop:3,color:node.alerting?'var(--clay)':C.meta}}>{node.meta}</div>
      </div>
    </div>
  );
}

const PARTS = [
  { id:'p1', title:'Retry with backoff', meta:'exponential · jitter', kind:'service' },
  { id:'p2', title:'Retry envelope', meta:'queue + worker + dlq', kind:'queue' },
  { id:'p3', title:'Idempotency guard', meta:'key store · 24h', kind:'store' },
  { id:'p4', title:'Fan-out publisher', meta:'3 subscribers', kind:'queue' }
];

const HISTORY = [
  { id:'h1', title:'Placed Retry envelope', meta:'12:04 · you', tone:'green' },
  { id:'h2', title:'Renamed Order queue', meta:'11:58 · you', tone:'neutral' },
  { id:'h3', title:'Branched async-fulfilment', meta:'11:31 · RK', tone:'purple' },
  { id:'h4', title:'Deleted Legacy retry', meta:'10:47 · MA', tone:'clay' }
];

function PlacementMenu({ onPick, onClose }) {
  const item = (glyph,label,id,danger) => (
    <div key={id} onClick={() => { onPick(id); onClose(); }}
      style={{display:'flex',alignItems:'center',gap:10,padding:'8px 9px',borderRadius:7,cursor:'pointer',
        color:danger?'var(--clay)':'var(--text-primary)'}}
      onMouseEnter={e=>e.currentTarget.style.background='var(--sunken)'}
      onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
      <span style={{fontSize:12}}>{glyph}</span><span style={{fontSize:13}}>{label}</span>
    </div>
  );
  return (
    <div style={{position:'absolute',top:36,right:8,width:210,background:'var(--canvas-white)',border:'1px solid var(--border)',
      borderRadius:11,boxShadow:'var(--shadow-popover)',padding:'8px 8px 6px',zIndex:20}}>
      <div style={{...mono,fontSize:9,letterSpacing:'0.12em',color:C.meta,padding:'5px 9px 6px'}}>PLACEMENT</div>
      {item('⇥','Dock right','right')}
      {item('⇤','Dock left','left')}
      {item('⧉','Float','floating')}
      {item('⊣','Collapse','collapsed')}
      <div style={{height:1,background:'var(--hairline-soft)',margin:'5px 4px'}}></div>
      {item('✕','Close panel','closed',true)}
    </div>
  );
}

function PanelBody({ tab, onPlace, onDrag }) {
  const [query, setQuery] = useState('');
  if (tab === 'history') {
    return (
      <div style={{display:'flex',flexDirection:'column',gap:7,padding:14,overflow:'auto'}}>
        {HISTORY.map(h => (
          <div key={h.id} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 9px',borderRadius:8,
            background:'var(--shell)',border:'1px solid var(--hairline)'}}>
            <span style={{width:8,height:8,borderRadius:'50%',background:
              h.tone==='green'?'var(--green)':h.tone==='purple'?'var(--purple)':h.tone==='clay'?'var(--clay)':'var(--text-disabled)'}}></span>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:12.5,fontWeight:600}}>{h.title}</div>
              <div style={{...mono,fontSize:9.5,color:C.meta,marginTop:2}}>{h.meta}</div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  const rows = PARTS.filter(p => p.title.toLowerCase().includes(query.toLowerCase()));
  return (
    <div style={{display:'flex',flexDirection:'column',gap:9,padding:14,overflow:'auto'}}>
      <div style={{display:'flex',alignItems:'center',gap:8,background:'var(--panel)',border:'1px solid '+(query?'var(--green)':'var(--border)'),
        boxShadow:query?'var(--ring-soft)':'none',borderRadius:7,padding:'7px 9px'}}>
        <span style={{fontSize:11,color:query?'var(--green)':C.meta}}>⌕</span>
        <input value={query} placeholder="Search the library" onChange={e=>setQuery(e.target.value)}
          style={{flex:1,minWidth:0,border:'none',outline:'none',background:'transparent',fontFamily:'var(--font-ui)',fontSize:12.5}}/>
        {query ? <span onClick={()=>setQuery('')} style={{fontSize:11,color:C.meta,cursor:'pointer'}}>✕</span>
               : <span style={{...mono,fontSize:9.5,color:'var(--text-placeholder)'}}>P</span>}
      </div>
      {rows.length === 0 && (
        <div style={{border:'1px dashed var(--border)',borderRadius:9,padding:'22px 16px',textAlign:'center',
          display:'flex',flexDirection:'column',gap:8,alignItems:'center'}}>
          <span style={{fontSize:18,color:'var(--text-disabled)'}}>⊞</span>
          <span style={{fontSize:12.5,fontWeight:600}}>Nothing matches “{query}”</span>
          <span style={{fontSize:12,color:'var(--text-secondary)',maxWidth:220,lineHeight:1.5}}>Clear the filter, or save the current selection as a new part.</span>
        </div>
      )}
      {rows.map(p => (
        <div key={p.id} onClick={() => onPlace(p)}
          style={{display:'flex',alignItems:'center',gap:10,padding:'8px 9px',borderRadius:8,cursor:'pointer',
            background:'var(--shell)',border:'1px solid var(--hairline)'}}
          onMouseEnter={e=>{e.currentTarget.style.background='var(--canvas-white)';e.currentTarget.style.borderColor='var(--border)';e.currentTarget.style.boxShadow='var(--shadow-raised)';}}
          onMouseLeave={e=>{e.currentTarget.style.background='var(--shell)';e.currentTarget.style.borderColor='var(--hairline)';e.currentTarget.style.boxShadow='none';}}>
          <span style={{width:26,height:26,flex:'0 0 26px',borderRadius:7,background:'var(--sunken)',border:'1px solid var(--border)',
            color:C.body,fontSize:12,display:'flex',alignItems:'center',justifyContent:'center'}}>⧉</span>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:12.5,fontWeight:600}}>{p.title}</div>
            <div style={{...mono,fontSize:9.5,color:C.meta,marginTop:2}}>{p.meta}</div>
          </div>
          <span style={{...mono,fontSize:9.5,color:'var(--text-disabled)'}}>place</span>
        </div>
      ))}
    </div>
  );
}

function Studio() {
  const [nodes, setNodes] = useState([
    { id:'n1', title:'Checkout API', meta:'SERVICE · p99 180ms', kind:'service', x:60, y:70 },
    { id:'n2', title:'Order queue', meta:'QUEUE · depth 1.2k', kind:'queue', x:300, y:150 },
    { id:'n3', title:'Dead letter store', meta:'8.1% OF TRAFFIC PARKED', kind:'store', x:300, y:280, alerting:true }
  ]);
  const [selected, setSelected] = useState('n1');
  const [tab, setTab] = useState('library');
  const [placement, setPlacement] = useState('right');
  const [menu, setMenu] = useState(false);
  const [toast, setToast] = useState(null);
  const [zoom, setZoom] = useState(100);

  const place = (part) => {
    const id = 'n' + (nodes.length + 1);
    setNodes(n => [...n, { id, title: part.title, meta: part.meta.toUpperCase(), kind: part.kind, x: 120 + n.length * 26, y: 300 + n.length * 14 }]);
    setSelected(id);
    setToast(part.title + ' placed');
    setTimeout(() => setToast(null), 2600);
  };

  const collapsed = placement === 'collapsed';
  const closed = placement === 'closed';

  const tabStrip = (
    <div style={{display:'flex',alignItems:'center',borderBottom:'1px solid var(--hairline)',cursor:'grab',position:'relative',background:'var(--canvas-white)'}}>
      {[{id:'library',label:'Library',count:PARTS.length},{id:'history',label:'History',count:HISTORY.length}].map(t => {
        const on = t.id === tab;
        return (
          <div key={t.id} onClick={() => setTab(t.id)}
            style={{padding:'9px 13px',display:'flex',alignItems:'center',gap:7,borderBottom:'2px solid '+(on?'var(--green)':'transparent'),cursor:'pointer'}}>
            <span style={{fontSize:12.5,fontWeight:on?600:400,color:on?'var(--green)':'var(--text-secondary)'}}>{t.label}</span>
            <span style={{...mono,fontSize:9,borderRadius:20,padding:'1px 7px',color:on?'var(--text-on-green)':C.body,background:on?'var(--green)':'var(--sunken)'}}>{t.count}</span>
          </div>
        );
      })}
      <span style={{marginLeft:'auto',paddingRight:8}}><Icon glyph="⋯" size={26} onClick={() => setMenu(m => !m)} title="Placement"/></span>
      {menu && <PlacementMenu onPick={setPlacement} onClose={() => setMenu(false)}/>}
    </div>
  );

  const panel = (
    <div style={{width:300,flex:'0 0 300px',display:'flex',flexDirection:'column',background:'var(--canvas-white)',
      borderLeft:placement==='right'?'1px solid var(--hairline)':undefined,
      borderRight:placement==='left'?'1px solid var(--hairline)':undefined,
      ...(placement==='floating'?{position:'absolute',right:34,top:76,height:420,border:'1px solid var(--border)',
        borderRadius:12,boxShadow:'var(--shadow-floating)',overflow:'hidden',zIndex:15}:{})}}>
      {tabStrip}
      <PanelBody tab={tab} onPlace={place}/>
    </div>
  );

  const rail = (
    <div style={{width:44,flex:'0 0 44px',background:'var(--canvas-white)',borderLeft:'1px solid var(--hairline)',
      display:'flex',flexDirection:'column',alignItems:'center',gap:6,padding:'10px 0',cursor:'pointer'}}
      onClick={() => setPlacement('right')} title="Expand panel">
      <span style={{fontSize:14,color:'var(--green)'}}>⊞</span>
      <span style={{...mono,fontSize:9,writingMode:'vertical-rl',letterSpacing:'0.1em',color:C.meta,marginTop:6}}>LIBRARY</span>
      <span style={{width:6,height:6,borderRadius:'50%',background:'var(--green)',marginTop:8}}></span>
    </div>
  );

  return (
    <div style={{height:'100%',display:'flex',flexDirection:'column',background:'var(--shell)',fontFamily:'var(--font-ui)',color:'var(--text-primary)'}}>
      <div style={{height:50,flex:'0 0 50px',display:'flex',alignItems:'center',gap:12,padding:'0 14px',background:'var(--canvas-white)',borderBottom:'1px solid var(--hairline)'}}>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <div style={{width:20,height:20,borderRadius:5,background:'linear-gradient(140deg,#0B5C54,#2E7D6B)'}}></div>
          <span style={{fontSize:14.5,fontWeight:600,letterSpacing:'-0.01em'}}>System studio</span>
        </div>
        <span style={{width:1,height:20,background:'var(--hairline)'}}></span>
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{fontSize:13,fontWeight:500}}>Checkout path</span>
          <span style={{color:'var(--text-disabled)',fontSize:11}}>/</span>
          <span style={{fontSize:11,color:'var(--purple)'}}>⑂</span>
          <span style={{fontSize:13,fontWeight:500,color:'var(--purple)'}}>async-fulfilment</span>
        </div>
        <span style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:12}}>
          <Tag tone="clay">UNSAVED</Tag>
          <span style={{display:'flex'}}>
            <span style={{width:26,height:26,borderRadius:'50%',background:'var(--green)',color:'var(--text-on-green)',fontSize:10.5,fontWeight:600,display:'flex',alignItems:'center',justifyContent:'center',border:'2px solid #fff'}}>RK</span>
            <span style={{width:26,height:26,borderRadius:'50%',background:'var(--purple)',color:'var(--text-on-green)',fontSize:10.5,fontWeight:600,display:'flex',alignItems:'center',justifyContent:'center',border:'2px solid #fff',marginLeft:-8}}>MA</span>
          </span>
          <button style={{font:'600 13px var(--font-ui)',color:'var(--text-on-green)',background:'var(--green)',border:'none',borderRadius:7,padding:'8px 16px',cursor:'pointer'}}>Run simulation</button>
        </span>
      </div>

      <div style={{flex:1,minHeight:0,display:'flex',position:'relative'}}>
        {placement === 'left' && panel}
        <div style={{flex:1,minWidth:0,position:'relative',overflow:'hidden',background:'var(--canvas-white)',
          backgroundImage:'var(--canvas-dot)',backgroundSize:'var(--canvas-dot-size)'}}>
          <div style={{position:'absolute',inset:0,transform:'scale('+(zoom/100)+')',transformOrigin:'top left'}}>
            {nodes.map(n => <NodeCard key={n.id} node={n} selected={n.id===selected} onSelect={setSelected}/>)}
          </div>

          <div style={{position:'absolute',left:'50%',bottom:22,transform:'translateX(-50%)',display:'flex',alignItems:'center',gap:8,
            padding:'7px 9px',background:'var(--canvas-white)',border:'1px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow-floating)'}}>
            <div style={{display:'flex',gap:2}}><Icon glyph="↺" title="Undo"/><Icon glyph="↻" state="disabled"/></div>
            <span style={{width:1,height:22,background:'var(--hairline-soft)'}}></span>
            <div style={{display:'flex',gap:3,alignItems:'center'}}>
              <span style={{display:'flex',alignItems:'center',gap:7,height:32,padding:'0 11px',borderRadius:8,background:'var(--green-tint)',border:'1px solid var(--green-edge)',color:'var(--green)'}}>
                <span style={{fontSize:13}}>↖</span><span style={{fontSize:13,fontWeight:600}}>Select</span></span>
              <Icon glyph="✥"/>
            </div>
            <span style={{width:1,height:22,background:'var(--hairline-soft)'}}></span>
            <div style={{display:'flex',gap:3,alignItems:'center'}}>
              <span onClick={() => setPlacement(placement==='closed'?'right':'closed')}
                style={{display:'flex',alignItems:'center',gap:7,height:32,padding:'0 11px',borderRadius:8,cursor:'pointer',
                  background:closed?'transparent':'var(--ink)',color:closed?'var(--text-body)':'var(--text-on-ink)',
                  border:'1px solid '+(closed?'transparent':'var(--ink)')}}>
                <span style={{fontSize:13}}>⊞</span><span style={{fontSize:13,fontWeight:600}}>Part</span></span>
              <Icon glyph="⇢"/><Icon glyph="✎"/>
            </div>
            <span style={{width:1,height:22,background:'var(--hairline-soft)'}}></span>
            <div style={{display:'flex',gap:2,alignItems:'center'}}>
              <Icon glyph="−" onClick={() => setZoom(z => Math.max(50, z - 10))}/>
              <span style={{...mono,minWidth:44,textAlign:'center',fontSize:11.5,fontWeight:500,color:C.body}}>{zoom}%</span>
              <Icon glyph="＋" onClick={() => setZoom(z => Math.min(160, z + 10))}/>
              <Icon glyph="⤢" onClick={() => setZoom(100)}/>
            </div>
          </div>

          {toast && (
            <div style={{position:'absolute',left:24,bottom:26,display:'inline-flex',alignItems:'center',gap:14,background:'var(--ink)',
              color:'var(--text-on-ink)',borderRadius:10,padding:'10px 14px',boxShadow:'var(--shadow-toast)'}}>
              <span style={{fontSize:12.5}}>{toast}</span>
              <span style={{fontSize:12,color:'var(--green-edge-strong)',cursor:'pointer'}}>Undo</span>
            </div>
          )}
        </div>
        {placement === 'right' && panel}
        {placement === 'floating' && panel}
        {collapsed && rail}
      </div>

      <div style={{height:44,flex:'0 0 44px',display:'flex',alignItems:'center',gap:14,padding:'0 14px',background:'var(--canvas-white)',borderTop:'1px solid var(--hairline)'}}>
        <span style={{display:'flex',alignItems:'center',gap:7,fontSize:12.5}}>
          <span style={{width:8,height:8,borderRadius:'50%',background:'var(--green)',boxShadow:'0 0 0 3px rgba(11,92,84,0.14)'}}></span>Live</span>
        <span style={{...mono,fontSize:10,color:C.meta}}>{nodes.length} PARTS · v4 · PLATFORM TEAM</span>
        <span style={{marginLeft:'auto',display:'flex',gap:14,...mono,fontSize:10,color:C.meta}}>
          <span>↵ place</span><span>⇥ keep open</span><span>esc close</span></span>
      </div>
    </div>
  );
}

window.Studio = Studio;
