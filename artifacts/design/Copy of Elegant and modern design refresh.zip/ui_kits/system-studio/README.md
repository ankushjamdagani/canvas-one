# System Studio — UI kit

One screen: the architecture canvas with its floating dock and the side panel that carries History and the Components Library.

**What is interactive**
- Tabs switch between Library and History; the tab strip is the panel header and the drag handle.
- The tab-strip ⋯ menu moves the panel: dock right, dock left, float, collapse to a rail, close. Collapsed shows the 44px rail with its change dot; clicking the rail re-docks it.
- Clicking a library row places that part on the canvas and raises the toast.
- The library search filters, and shows the empty state when nothing matches.
- Dock zoom −/＋/⤢ scales the canvas; the Part chip toggles the panel.
- Clicking a node selects it (green border and ring).

**Source** — recreated from `System Studio Directions.dc.html` (turn 23 panel-placement boards, the nav board, and the bottom action bar boards) and `System Studio Design System.dc.html`.

**Note** — this screen inlines its own copies of the primitives so it renders standalone in any browser. The values match `components/` exactly; when building inside a consuming project, import the real components instead.
