# System Studio — design system

System Studio is an architecture-design tool: an infinite canvas where a team lays out the parts of a system (services, queues, stores), saves groups of them as reusable **parts** in a Components Library, branches a diagram, and runs simulations against it. The interface is a paper-coloured workspace with one floating dock and side panels that the user can dock right, dock left, float, or collapse to a rail.

The system is deliberately quiet. Stone-paper surfaces, one green action colour, mono type for every number, and no decoration that does not carry state.

## Sources

Everything here was read out of two files in this project — there was no codebase, Figma file, or brand kit:

- `System Studio Design System.dc.html` — the authored UI library: colour, type, radius, elevation, and every control drawn in each of its states. This is the source of truth for token values.
- `System Studio Directions.dc.html` — the exploration boards: navigation, the bottom action bar, and turn 23's panel-placement states (23a–23g). Source of truth for chrome metrics and app behaviour.

No logo files, icon sets, or imagery were supplied. The app mark in the chrome is a 20px rounded square filled `linear-gradient(140deg,#0B5C54,#2E7D6B)` — that gradient square is the only mark the designs contain, and it is reproduced as-is rather than invented.

## Content fundamentals

Copy is flat, specific and unhurried. It names the thing and stops.

- **Sentence case everywhere** except mono metadata, which is uppercase. Buttons read "Run simulation", "Save, then switch", "Save selection as part".
- **No exclamation, no encouragement, no emoji.** The tool never congratulates.
- **Second person only when the state is about you**: "You are on branch async-fulfilment". Otherwise the subject is the object: "Run 13 is unsaved", "Retry envelope placed".
- **Consequences are stated, not implied**: "Switching to main will discard it."
- **Empty states name the query and offer the next move**: "Nothing matches “retry”" / "Clear the filter, or save the current selection as a new part."
- **Numbers live in mono and carry their unit**: `p99 180ms`, `depth 1.2k`, `8.1% OF TRAFFIC PARKED`, `3 PARTS · PLATFORM TEAM · v4`.
- Feature nouns are lowercase in prose (a part, a branch, the dock, the library) and capitalised only as UI labels.

## Visual foundations

**Colour.** A warm stone paper stack — canvas white `#FFFFFF`, shell `#FBFAF7`, panel `#F7F5F1`, sunken `#F2EFE9`, desk `#E9E7E2` — under near-black ink `#16201D`. Three accents and no more: green `#0B5C54` is the only action colour (selected, live, clickable — it never decorates); purple `#7C5FC0` marks branches, queues and async edges; clay `#B4674A` marks risk, destruction and unsaved work. Each accent has a tint fill and an edge colour so it can be worn by a chip as well as a line. One warm outlier: sticky notes on `#FBF6E8`.

**Type.** Newsreader (300–400) for document voice — board titles, section headings, anything with a page feeling. IBM Plex Sans for the entire app chrome: titles 18/600, UI 13/500, body 13/400 at 1.55. IBM Plex Mono at 9–11px, uppercase, `0.08–0.14em` tracking for metadata only — counts, types, keys, timestamps, never prose. Spline Sans appears on the exploration boards as board-level annotation.

**Spacing.** Dense inside chrome (7–14px paddings, 2–10px gaps), generous on boards (20–56px). Chrome metrics are fixed: 50–54px top bar, 34px panel section bar, 44px collapsed rail, 32px controls, 176px nodes.

**Backgrounds.** Flat colour, with one texture: the canvas dot grid, `radial-gradient(#EFEBE3 1px, transparent 1px)` at 26px. No photography, no illustration, no gradient fields. The one gradient in the whole system is the 20px app mark.

**Borders and corners.** Everything has a hairline. Four line weights: `#EFEBE3` (internal dividers), `#E7E3DB` (panel edges), `#DCD7CD` (control default), `#C6C0B4` (control hover). Radius is a vocabulary, not a scale: 4 tags, 7 controls, 9 nodes, 11 popovers, 12 cards, 14 the dock.

**Elevation.** Four steps, each with one job. Raised `0 1px 2px` for hovered rows. Popover `0 18px 32px -16px` for menus and selects. Floating `0 20px 44px -18px` + `0 2px 6px` reserved for the dock and floating panels — nothing else. Toast `0 18px 32px -16px rgba(...,0.5)` on ink. Shadows are cool-black `rgba(22,32,29,…)`, never grey.

**States.** Hover is a one-step darkening of fill plus one step of border (`#F2EFE9`→`#EAE6DE`, `#DCD7CD`→`#C6C0B4`); pressed is a second step down. Green fills go `#0B5C54`→`#0A4E47`→`#083F3A`. Focus is never subtle: a 3px green ring at 10% on fields, 18% on controls, 28% on filled buttons, clay at 28% on destructive. Disabled drops to `#C0C6C1` ink on `#F7F5F1` — dimmed, never invisible, and always with a reason beside it. Drag states tilt `-0.6deg`, switch to a dashed green border, and take a deep drop shadow.

**Transparency and blur.** Used twice only: the subsystem boundary fill `rgba(234,239,236,0.5)` and the selection marquee `rgba(11,92,84,0.08)`. No frosted glass anywhere.

**Motion.** Restrained and short. Panels snap between placements rather than animating a path; the drag ghost follows the cursor; the working spinner is a 2px ring rotating on `currentColor`. Nothing bounces. Nothing fades in on load.

**Cards.** White fill, `#E7E3DB` hairline, 12px radius, 24px padding, no shadow at rest. Canvas nodes are the exception: 9px radius, 176px wide, with a 3px top stripe that names the node kind while the border carries selection state.

## Iconography

The designs use **unicode glyphs**, not an icon library: `↺ ↻ ⊞ ⧉ ✎ ⋯ ⌫ ⤓ ⇢ ✥ ↖ ⌕ ✕ ✓ ⑂ ≡ ⊪ ＋ − ⤢ ▾ ▴`. They are set in the UI font at 11–16px and coloured by state (`--text-body` at rest, `--text-primary` on hover, `--green` when active). `⑂` always means branch; `⊞` always means part or library; `⧉` always means a saved part.

No icon font, sprite sheet, or SVG set exists in the sources, so nothing was copied into `assets/` and nothing was substituted from a CDN. Keep using the glyph set above; if the product ever needs a real icon library, that is a decision to make deliberately, not by importing one here. Emoji are never used.

## Intentional additions

- **IconButton** — the glyph buttons are drawn repeatedly in the source library (dock, panel headers, rails) but never named; it is factored out here so the 32px box and its five states stay consistent.
- **Dock** — the source draws the dock as one specimen; it is componentised with a `groups` API so consumers cannot invent a second floating bar.

## Index

- `styles.css` — the single stylesheet to link. Imports everything below.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `shape.css`.
- `guidelines/` — 17 specimen cards: colour ramps, type specimens, radius, elevation, focus rings, spacing, chrome metrics, status dots, tags, keycaps.
- `components/`
  - `core/` — Button, IconButton, Tag, CountBadge, StatusDot, KeyHint
  - `forms/` — TextInput, SearchField, Select, Checkbox, Radio, Toggle, Stepper, Slider
  - `navigation/` — Tabs, Segmented, Breadcrumb, RailItem, Menu
  - `feedback/` — InlineAlert, Toast, Tooltip, Meter, EmptyState
  - `canvas/` — Node, Boundary, StickyNote, Dock
  - `surfaces/` — Panel, LibraryRow, AvatarStack
- `ui_kits/system-studio/` — the interactive studio screen (canvas, dock, dockable panel).
- `SKILL.md` — entry point when this system is used as an agent skill.

## Rules of use

1. **One primary per surface.** A single filled green button; everything else is secondary, tint or ghost.
2. **Green means action.** If something is green it is selected, live, or the thing to click.
3. **Mono is metadata.** Uppercase Plex Mono at 9–10px for counts, types, keys and timestamps — never for prose.
4. **Focus is always visible.** Every interactive element takes the 3px ring. Hover may be subtle; focus may not.
5. **One floating bar.** The dock owns the floating shadow; popovers use the lighter popover shadow.
6. **Disabled still reads.** `#C0C6C1` on `#F7F5F1`, with the reason nearby.
7. **Placement lives in the panel header**, not in settings — the ⋯ / ⊞ control on the tab strip moves a panel right, left, floating or collapsed.
